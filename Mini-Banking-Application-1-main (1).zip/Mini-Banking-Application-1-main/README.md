# Mini-Banking-Application
A Java-based mini banking application using JDBC for transaction management, allowing account creation, login, balance viewing, and transfers.
